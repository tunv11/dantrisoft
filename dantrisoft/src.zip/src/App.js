/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 * @lint-ignore-every XPLATJSCOPYRIGHT1
 */

import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, WebView } from 'react-native';
import Utils from './Utils';
import DialogDevice from './DialogDevice';
import Permissions from 'react-native-permissions'
import RNFetchBlob from "react-native-fetch-blob";
import { BleManager, LogLevel } from "react-native-ble-plx";

export default class App extends Component {

  constructor(props) {
    super(props);
    this.manager = new BleManager();
    this.state = {
      locationPermission: null,
      bluetoothPermission: null,
      base64PDF: null
    }

    this.makingAddFun = false;
  }
  // Check the status of a single permission
  componentDidMount() {
    Permissions.request('location').then(response => {
      // Response is one of: 'authorized', 'denied', 'restricted', or 'undetermined'
      this.setState({ locationPermission: response })
    })
    if (Utils.isIOS()) {
      Permissions.request('bluetooth').then(response => {
        // Response is one of: 'authorized', 'denied', 'restricted', or 'undetermined'
        this.setState({ bluetoothPermission: response })
      })
    }
  }

  render() {
    return (
      <View style={styles.content}>
        <WebView
          style={styles.container}
          source={{ uri: "http://orderblu.dantrisoft.vn/#/login" }}
          onMessage={data => this.onMessage(data)}
          originWhitelist={['*']}
          javaScriptEnabled={true}
          allowFileAccess={true}
          originWhitelist={['*']}
          useWebKit={true}
        />
        <DialogDevice
          ref={(popupDialog) => { this.popupDialog = popupDialog; }}
          onPress={(connectedDevice, name, id) => this._handlerConnectedDevice(connectedDevice, name, id)}
        />
      </View>

    );
  }

  _handlerConnectedDevice = async (serviceUUIDs, name, id) => {
    console.log('_handlerConnectedDevice \n' + serviceUUIDs)
    console.log('_handlerConnectedDevice \n' + name)
    console.log('_handlerConnectedDevice \n' + id)
    // return
    try {
      try {
        await this.manager.connectToDevice(id)
          .then((device) => {
            console.log("connectToDevice", device.id)
            return device.discoverAllServicesAndCharacteristics()
            // device.writeCharacteristicWithResponseForService(serviceUUIDs, serviceUUIDs, 'aGVsbG8gbWlzcyB0YXBweQ==')
            //   .then((characteristic) => {
            //     console.log(characteristic.value)
            //   })
            //   .catch((error) => {
            //     console.error(error.message)
            //   })
          })
      } catch (e) {
        console.error("connect failed", e);
        return;
      }
      await this.manager.discoverAllServicesAndCharacteristicsForDevice(id).
        then((characteristic) => {
          console.log("discoverAllServicesAndCharacteristicsForDevice" + characteristic);
        })
      await this.manager.characteristicsForDevice(id, serviceUUIDs.toString()).then((characteristic) => {
        this.manager.writeCharacteristicWithResponseForDevice(
          id,
          serviceUUIDs.toString(),
          characteristic,
          "aGVsbG8gbWlzcyB0YXBweQ=="
        ).catch((error) => {
          console.log('error in writing data');
          console.log(error);
        })
      })
    } catch (e) {
      return;
    }

  }

  onMessage(data) {
    console.log('data -----\n' + JSON.stringify(data.nativeEvent.data));
    //Prints out data that was passed.
    // alert(data.nativeEvent.data);
    // if (this.state.locationPermission == "authorized") {
    //   if (Utils.isAndroid()) {
    //     if (!this.state.bluetoothPermission == "authorized") {
    //       return
    //     }
    //   }
    this.popupDialog.showSlideAnimationDialog()
    const fs = RNFetchBlob.fs;
    RNFetchBlob.config({
      fileCache: true
    })
      .fetch("GET", data.nativeEvent.data)
      // the image is now dowloaded to device's storage
      .then(resp => {
        // the image path you can use it directly with Image component
        imagePath = resp.path();
        return resp.readFile("base64");
      })
      .then(base64Data => {
        // here's base64 encoded image
        console.log('test -----\n' + base64Data);
        this.setState({ base64PDF: base64Data })
        this.manager.w
        // remove the file from storage
        return fs.unlink(imagePath);
      });
    // }
  }
}

const styles = StyleSheet.create({
  content: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});
