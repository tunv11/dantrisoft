import React, { Component, Fragment } from "react";
import {
    Text,
    View,
    FlatList,
    TouchableOpacity,
    ActivityIndicator,
    PermissionsAndroid,
    Alert,
    StyleSheet
} from "react-native";
import Utils from './Utils';
import PopupDialog, { DialogTitle, DialogButton, SlideAnimation, ScaleAnimation, FadeAnimation, } from 'react-native-popup-dialog';
import { BleManager } from "react-native-ble-plx";

const slideAnimation = new SlideAnimation({ slideFrom: 'bottom' });

export default class DialogDevice extends Component {

    constructor(props) {
        super(props);
        this.manager = new BleManager();
        this.onPress = props.onPress;
        this.state = {
            devices: [],
            connectedDevice: null,
            loading: false,
            disabled: false,
        };
        this.devices = {};
    }

    async componentDidMount() {
        await this.requestLocationPermission();
        const subscription = this.manager.onStateChange(state => {
            if (state === "PoweredOn") {
                this.scan();
                subscription.remove();
            }
        }, true);
    }

    /* Scan for devices and connect to valrt devices automatically */
    scan() {
        this.manager.startDeviceScan(null, null, (e, device) => {
            if (e) {
                // Handle error (scanning will be stopped automatically)
                console.error("scan failed", e);
                return;
            }

            if (!device || device.name == null) {
                return;
            }

            // ensure device is unique
            if (!this.devices[device.id]) {
                this.devices[device.id] = device.id;
                const item = { device, key: device.id };
                this.setState({ devices: [...this.state.devices, item] });
            }

            // Check if it is a device you are looking for based on advertisement data
            // or other criteria.
            // if (
            //     device.name &&
            //     device.name.toLowerCase().includes("v.alrt") &&
            //     this.state.disabled === false &&
            //     this.state.loading === false &&
            //     this.state.connectedDevice === null
            // ) {
            //     // Proceed with connection.
            //     this.connect(device);
            // }
        });
    }

    /* Connect to device */
    connect = async device => {
        if (this.state.disabled) {
            Alert.alert("Cannot Connect", "Service is disabled.");
            return;
        }

        if (
            this.state.connectedDevice &&
            this.state.connectedDevice.id === device.id
        ) {
            Alert.alert("Cannot Connect", "Device is already connected.");
            return;
        }

        // if (!device.name) {
        //   Alert.alert(
        //     "Cannot Connect",
        //     "It is not possible to connect to this device. Try another device with a device name."
        //   );
        //   return;
        // }

        this.setState({ loading: true });
        try {
            await this.manager.connectToDevice(device.id);
        } catch (e) {
            this.setState({ loading: false });
            // console.error("connect failed", e);
            return;
        }

        this.setState({ connectedDevice: device, loading: false }, async () => {
            this.slideAnimationDialog.dismiss();
            var temapconnectedDevice = this.state.connectedDevice;
            await this.disconnect()
            // console.log('temapconnectedDevice \n' + temapconnectedDevice.serviceUUIDs)
            // console.log('temapconnectedDevice \n' + temapconnectedDevice.name)
            // console.log('temapconnectedDevice \n' + temapconnectedDevice.id)
            this.onPress(temapconnectedDevice.serviceUUIDs, temapconnectedDevice.name, temapconnectedDevice.id);
       
        });
        // this.monitorDisconnect(device);
        // this.monitor(device);


    };

    /* Monitor services and characteristics */
    monitor = async device => {
        try {
            await device.discoverAllServicesAndCharacteristics();
        } catch (e) {
            console.error("discoverAllServicesAndCharacteristics failed", e);
            return;
        }
        // device.monitorCharacteristicForService(
        //   SERVICE,
        //   CHARACTERISTIC,
        //   (e, data) => {
        //     if (e) {
        //       console.error("monitorCharacteristicForService failed", e);
        //       return;
        //     }
        //     console.log("test", e, data);
        //     if (data.value === "AA==") {
        //       Open.googleAssistant();
        //     }
        //   }
        // );
    };

    monitorDisconnect = device => {
        device.onDisconnected(() => {
            console.warn("onDeviceDisconnected called");
            this.setState({ connectedDevice: null });
        });
    };

    disconnect = async () => {
        console.log("disconnect1")
        if (!this.state.connectedDevice) {
            this.setState({ disabled: true });
            return;
        }
        this.setState({ loading: true });
        try {
            await this.manager.cancelDeviceConnection(
                this.state.connectedDevice.id
            );
        } catch (e) {
            console.error("cancelDeviceConnection failed", e);
        }
        this.setState({
            connectedDevice: null,
            loading: false,
            disabled: false
        }, () => {
            console.log("disconnect1")
        });
    };

    enable = () => {
        this.setState({ disabled: false });
    };

    async requestLocationPermission() {
        try {
            const granted = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION
            );
            if (granted === PermissionsAndroid.RESULTS.GRANTED) {
                console.log("You can use bluetooth");
            } else {
                console.log("Bluetooth permission denied");
            }
        } catch (e) {
            console.error(e);
        }
    }


    showSlideAnimationDialog = () => {
        this.slideAnimationDialog.show();
    }

    dismissSlideAnimationDialog = () => {
        this.slideAnimationDialog.dismiss();
    }

    renderListItem = ({ item }) => {
        const isConnectedDevice =
            this.state.connectedDevice && this.state.connectedDevice.id === item.device.id;

        return (
            <TouchableOpacity
                onPress={() => this.connect(item.device)}
                style={styles.listItem}  >
                <Text style={styles.deviceName}>
                    {item.device.name || "Unknown Device Name"}
                </Text>
                <Text style={styles.text}>{item.key}</Text>
                {isConnectedDevice && <Text style={styles.greenText}>Connected</Text>}
            </TouchableOpacity>
        );
    };

    renderList = () => {
        // const { devices, loading } = this.props;

        if (this.state.loading) {
            return (
                <Fragment>
                    <ActivityIndicator size="large" color="#337AB7" />
                    <Text style={styles.text}>Loading...</Text>
                </Fragment>
            );
        }

        if (this.state.devices.length === 0)
            return (
                <Fragment>
                    <ActivityIndicator size="large" color="#337AB7" />
                    <Text style={styles.text}>Scanning...</Text>
                </Fragment>
            );

        return (
            <View style={{ flex: 1, alignSelf: "stretch" }}>
                <FlatList
                    extraData={this.props.connectedDevice}
                    data={this.state.devices}
                    renderItem={this.renderListItem}
                    style={styles.listContainer}
                />
            </View>
        );
    };

    render() {
        return (
            <PopupDialog
                dialogStyle={styles.background_dialog}
                width={Utils.appSize().width - 50}
                ref={(popupDialog) => {
                    this.slideAnimationDialog = popupDialog;
                }}
                dialogAnimation={slideAnimation}
                onDismissed={() => Utils.dismissKeyboard()}>
                <View style={styles.container}>
                    <Text style={styles.text}>Vui lòng chọn máy in</Text>
                    {this.renderList()}
                </View>
            </PopupDialog>
        )
    }


}

const styles = StyleSheet.create({
    background_dialog: {
        backgroundColor: 'transparent',
    },
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "white"
    },
    button: {
        alignSelf: "stretch",
        padding: 5,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#337AB7",
        height: 45,
        borderColor: "transparent",
        borderWidth: 0,
        marginLeft: 20,
        marginRight: 20,
        marginBottom: 20
    },
    text: {
        color: '#6f6f6f',
        fontSize: 16,
        textAlign: 'center',
        width: '100%'
    },
    greenButton: {
        backgroundColor: "green"
    },
    redButton: {
        backgroundColor: "red"
    },
    buttonText: {
        color: "white"
    },
    greenText: {
        fontSize: 12,
        color: "green"
    },
    listContainer: {
        flex: 1,
        alignSelf: "stretch",
        marginBottom: 20
    },
    listItem: {
        flex: 1,
        padding: 20,
        alignSelf: "stretch",
        borderBottomWidth: 1,
        borderColor: "#D8D8D8",
        backgroundColor: "white"
    },
    deviceName: {
        fontSize: 18,
        color: "#4A90E2"
    },
    text: {
        fontSize: 12,
        color: "#BBBBBB"
    }
});
