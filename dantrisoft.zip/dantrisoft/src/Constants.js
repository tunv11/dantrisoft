/******************* Data ***********************/
export let KEY_DEVICE = "dantrisoft_key_device";